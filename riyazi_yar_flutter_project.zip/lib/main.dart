import 'package:flutter/material.dart';

void main() => runApp(const RiyaziYarApp());

class RiyaziYarApp extends StatelessWidget {
  const RiyaziYarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ریاضی‌یار هشتم',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xff7054d8),
        scaffoldBackgroundColor: const Color(0xfff7f5ff),
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int selected = 0;
  final pages = const [HomePage(), LessonsPage(), QuizPage(), GamePage()];

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          body: pages[selected],
          bottomNavigationBar: NavigationBar(
            selectedIndex: selected,
            onDestinationSelected: (v) => setState(() => selected = v),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), label: 'خانه'),
              NavigationDestination(icon: Icon(Icons.menu_book), label: 'آموزش'),
              NavigationDestination(icon: Icon(Icons.quiz_outlined), label: 'آزمون'),
              NavigationDestination(icon: Icon(Icons.extension), label: 'بازی'),
            ],
          ),
        ),
      );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) => SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text('سلام ریاضی‌دان کوچولو! 👋',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('با ریاضی‌یار، یادگیری ریاضی هشتم لذت‌بخش می‌شود.'),
            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                    colors: [Color(0xff7054d8), Color(0xffa47bea)]),
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('آماده‌ای؟',
                      style: TextStyle(color: Colors.white, fontSize: 26,
                          fontWeight: FontWeight.bold)),
                  SizedBox(height: 10),
                  Text('امروز یک قدم به قهرمان ریاضی شدن نزدیک‌تر شو!',
                      style: TextStyle(color: Colors.white, fontSize: 16)),
                  SizedBox(height: 12),
                  Icon(Icons.calculate, color: Colors.white, size: 58),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const FeatureCard(icon: Icons.menu_book, title: 'آموزش درس‌ها',
                subtitle: 'نکته‌ها و مثال‌های مهم', color: Colors.blue),
            const FeatureCard(icon: Icons.quiz, title: 'آزمون هوشمند',
                subtitle: 'دانسته‌هایت را بسنج', color: Colors.orange),
            const FeatureCard(icon: Icons.extension, title: 'بازی ریاضی',
                subtitle: 'با معماها فکر کن و یاد بگیر', color: Colors.green),
            const SizedBox(height: 12),
            const Text('تهیه‌شده به‌عنوان پروژه آموزشی دانش‌آموزی',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black54, fontSize: 12)),
          ],
        ),
      );
}

class FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final Color color;
  const FeatureCard({super.key, required this.icon, required this.title,
    required this.subtitle, required this.color});

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: color.withValues(alpha: .13),
            child: Icon(icon, color: color)),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(subtitle),
        ),
      );
}

class Lesson {
  final String title, description, example;
  const Lesson(this.title, this.description, this.example);
}

class LessonsPage extends StatelessWidget {
  const LessonsPage({super.key});
  static const lessons = [
    Lesson('عددهای صحیح و گویا',
        'عدد گویا را می‌توان به صورت a/b نوشت؛ به شرط آنکه b صفر نباشد.',
        'مثال: ۱/۲، ۳/۴ و ۵- عددهای گویا هستند.'),
    Lesson('عددهای اول',
        'عدد اول، عدد طبیعی بزرگ‌تر از یک است که دقیقاً دو شمارنده مثبت دارد.',
        'مثال: ۲، ۳، ۵، ۷ و ۱۱ عددهای اول هستند.'),
    Lesson('چندضلعی‌ها',
        'چندضلعی شکلی بسته است که از پاره‌خط‌ها تشکیل شده است.',
        'مجموع زاویه‌های داخلی n ضلعی برابر (n−2)×۱۸۰ درجه است.'),
    Lesson('جبر و معادله',
        'در معادله، مقدار مجهول را پیدا می‌کنیم تا دو طرف تساوی برابر شوند.',
        'مثال: x + 5 = 12، پس x = 7.'),
    Lesson('مختصات',
        'هر نقطه روی صفحه مختصات با یک زوج مرتب مانند (۲،۳) مشخص می‌شود.',
        'عدد اول مختصات افقی و عدد دوم مختصات عمودی است.'),
    Lesson('آمار و احتمال',
        'احتمال برابر نسبت تعداد حالت‌های مطلوب به تعداد کل حالت‌های ممکن است.',
        'احتمال آمدن عدد ۳ در یک تاس سالم برابر ۱/۶ است.'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('آموزش ریاضی هشتم')),
        body: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: lessons.length,
          itemBuilder: (context, i) => Card(
            child: ExpansionTile(
              leading: CircleAvatar(child: Text('${i + 1}')),
              title: Text(lessons[i].title,
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              childrenPadding: const EdgeInsets.all(16),
              children: [
                Text(lessons[i].description),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.deepPurple.withValues(alpha: .08),
                    borderRadius: BorderRadius.circular(12)),
                  child: Text(lessons[i].example),
                ),
              ],
            ),
          ),
        ),
      );
}

class Question {
  final String text, explanation;
  final List<String> options;
  final int answer;
  const Question(this.text, this.options, this.answer, this.explanation);
}

const questions = [
  Question('حاصل ۵ + (۳-) کدام است؟', ['۲', '۸', '۲-', '۱۵'], 0,
      '۵ + (۳-) = ۲'),
  Question('کدام عدد اول است؟', ['۹', '۱۵', '۱۳', '۲۱'], 2,
      '۱۳ فقط بر ۱ و خودش بخش‌پذیر است.'),
  Question('اگر x + 4 = 10 باشد، x چند است؟', ['۴', '۵', '۶', '۱۴'], 2,
      'با کم کردن ۴ از دو طرف، x = ۶ می‌شود.'),
  Question('مجموع زاویه‌های داخلی مثلث چند درجه است؟',
      ['۹۰', '۱۸۰', '۲۷۰', '۳۶۰'], 1, 'مجموع زاویه‌های هر مثلث ۱۸۰ درجه است.'),
  Question('احتمال آمدن عدد ۶ در تاس سالم چقدر است؟',
      ['۱/۲', '۱/۳', '۱/۶', '۱/۴'], 2, 'یک حالت مطلوب از شش حالت ممکن داریم.'),
];

class QuizPage extends StatefulWidget {
  const QuizPage({super.key});
  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int index = 0, score = 0;
  int? selected;
  bool answered = false, finished = false;

  void choose(int value) {
    if (answered) return;
    setState(() {
      selected = value;
      answered = true;
      if (value == questions[index].answer) score++;
    });
  }

  void next() => setState(() {
        if (index == questions.length - 1) {
          finished = true;
        } else {
          index++;
          selected = null;
          answered = false;
        }
      });

  void restart() => setState(() {
        index = 0;
        score = 0;
        selected = null;
        answered = false;
        finished = false;
      });

  @override
  Widget build(BuildContext context) {
    if (finished) {
      return Scaffold(
        appBar: AppBar(title: const Text('نتیجه آزمون')),
        body: Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.emoji_events, color: Colors.orange, size: 90),
            const SizedBox(height: 16),
            const Text('آفرین! آزمون تمام شد.',
                style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text('نمره شما: $score از ${questions.length}',
                style: const TextStyle(fontSize: 21)),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: restart, child: const Text('شروع دوباره')),
          ]),
        ),
      );
    }

    final q = questions[index];
    return Scaffold(
      appBar: AppBar(title: const Text('آزمون ریاضی')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        LinearProgressIndicator(value: (index + 1) / questions.length),
        const SizedBox(height: 20),
        Text('سؤال ${index + 1} از ${questions.length}',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 18),
        Text(q.text, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        ...List.generate(q.options.length, (i) {
          Color? tileColor;
          if (answered && i == q.answer) tileColor = Colors.green.withValues(alpha: .16);
          if (answered && i == selected && i != q.answer) {
            tileColor = Colors.red.withValues(alpha: .16);
          }
          return Card(
            color: tileColor,
            child: ListTile(title: Text(q.options[i]), onTap: () => choose(i)),
          );
        }),
        if (answered) ...[
          const SizedBox(height: 12),
          Text(selected == q.answer ? 'آفرین! پاسخ درست است 🎉' : 'پاسخ درست نبود.'),
          const SizedBox(height: 8),
          Text(q.explanation),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: next,
            child: Text(index == questions.length - 1 ? 'دیدن نتیجه' : 'سؤال بعدی')),
        ],
      ]),
    );
  }
}

class GamePage extends StatefulWidget {
  const GamePage({super.key});
  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  final riddles = const [
    ['من عددی هستم که اگر در خودم ضرب شوم ۶۴ می‌شود. چه عددی هستم؟',
      '۸ یا ۸-'],
    ['سه برابر یک عدد برابر ۲۱ است. آن عدد چیست؟', '۷'],
    ['مجموع دو عدد ۱۰ و اختلاف آن‌ها ۲ است. عدد بزرگ‌تر چیست؟', '۶'],
  ];
  int current = 0;
  bool showAnswer = false;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('بازی و معمای ریاضی')),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.psychology, size: 85, color: Colors.deepPurple),
            const SizedBox(height: 20),
            const Text('کارآگاه ریاضی باش!',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 20),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Text(riddles[current][0],
                    textAlign: TextAlign.center, style: const TextStyle(fontSize: 19)),
              ),
            ),
            const SizedBox(height: 16),
            if (showAnswer)
              Text('پاسخ: ${riddles[current][1]}',
                  style: const TextStyle(fontSize: 19, color: Colors.green)),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => setState(() => showAnswer = !showAnswer),
              child: Text(showAnswer ? 'پنهان کردن پاسخ' : 'نمایش پاسخ')),
            OutlinedButton(
              onPressed: () => setState(() {
                current = (current + 1) % riddles.length;
                showAnswer = false;
              }),
              child: const Text('معمای بعدی')),
          ]),
        ),
      );
}
